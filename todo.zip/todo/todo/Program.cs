﻿using System;
using System.Collections.Generic;

namespace TodoListApp
{
    class Todo
    {
        public int Id { get; set; }
        public string Task { get; set; }
        public bool IsCompleted { get; set; }
    }

    class TodoList
    {
        static void Main(string[] args)
        {
            List<Todo> todoList = new List<Todo>();
            int idCounter = 1;

            while (true)
            {
                Console.WriteLine("1. List Todos");
                Console.WriteLine("2. Add Todo");
                Console.WriteLine("3. Edit Todo");
                Console.WriteLine("4. Remove Todo");
                Console.WriteLine("5. Exit");

                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    Console.WriteLine("1. List All Todos");
                    Console.WriteLine("2. List Pending Todos");
                    Console.Write("Enter your choice: ");
                    int listChoice = int.Parse(Console.ReadLine());

                    Console.WriteLine("Todo List:");
                    if (listChoice == 1)
                    {
                        for (int i = 0; i < todoList.Count; i++)
                        {
                            Console.WriteLine(todoList[i].Id + ". " + todoList[i].Task + " (" + (todoList[i].IsCompleted ? "Completed" : "Pending") + ")");
                        }
                    }
                    else if (listChoice == 2)
                    {
                        for (int i = 0; i < todoList.Count; i++)
                        {
                            if (!todoList[i].IsCompleted)
                            {
                                Console.WriteLine(todoList[i].Id + ". " + todoList[i].Task + " (" + (todoList[i].IsCompleted ? "Completed" : "Pending") + ")");
                            }
                        }
                    }
                }
                else if (choice == 2)
                {
                    Console.Write("Enter Todo: ");
                    todoList.Add(new Todo { Id = idCounter++, Task = Console.ReadLine(), IsCompleted = false });
                }
                else if (choice == 3)
                {
                    Console.Write("Enter Todo Id: ");
                    int todoId = int.Parse(Console.ReadLine());
                    Todo todo = todoList.Find(x => x.Id == todoId);
                    if (todo != null)
                    {
                        Console.Write("Enter New Todo: ");
                        todo.Task = Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Todo not found.");
                    }
                }
                else if (choice == 4)
                {
                    Console.Write("Enter Todo Id: ");
                    int todoId = int.Parse(Console.ReadLine());
                    Todo todo = todoList.Find(x => x.Id == todoId);
                    if (todo != null)
                    {
                        todoList.Remove(todo);
                    }
                    else
                    {
                        Console.WriteLine("Todo not found.");
                    }
                }
                else if (choice == 5)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
        }
    }
}
